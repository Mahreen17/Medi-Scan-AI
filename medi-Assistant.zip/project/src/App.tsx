import React, { useState } from 'react';
import { Search, FileText, AlertTriangle, Download, Shield, Users, Beaker, Eye } from 'lucide-react';

interface MedicineData {
  name: string;
  activeIngredients: string[];
  chemicalComposition: {
    compound: string;
    percentage: number;
    function: string;
    skinRisk: 'low' | 'medium' | 'high';
    confidenceScore: number;
  }[];
  sideEffects: string[];
  skinTypeRisks: {
    [key: string]: {
      risk: 'low' | 'medium' | 'high';
      description: string;
    };
  };
}

const mockMedicineData: MedicineData = {
  name: "Acetaminophen (Paracetamol)",
  activeIngredients: ["N-acetyl-p-aminophenol"],
  chemicalComposition: [
    {
      compound: "Acetaminophen",
      percentage: 65,
      function: "Analgesic and antipyretic agent",
      skinRisk: 'low',
      confidenceScore: 0.92
    },
    {
      compound: "Microcrystalline cellulose",
      percentage: 20,
      function: "Binding agent and filler",
      skinRisk: 'low',
      confidenceScore: 0.98
    },
    {
      compound: "Magnesium stearate",
      percentage: 10,
      function: "Lubricant and anti-adherent",
      skinRisk: 'medium',
      confidenceScore: 0.85
    },
    {
      compound: "Povidone",
      percentage: 5,
      function: "Binder and disintegrant",
      skinRisk: 'low',
      confidenceScore: 0.89
    }
  ],
  sideEffects: [
    "Rare: Skin rash or hives",
    "Very rare: Stevens-Johnson syndrome",
    "Uncommon: Allergic contact dermatitis"
  ],
  skinTypeRisks: {
    sensitive: {
      risk: 'medium',
      description: "May cause mild irritation due to inactive ingredients"
    },
    dry: {
      risk: 'low',
      description: "Generally well-tolerated with minimal drying effects"
    },
    oily: {
      risk: 'low',
      description: "No significant impact on sebum production"
    },
    combination: {
      risk: 'low',
      description: "Suitable for combination skin types"
    },
    acneprone: {
      risk: 'low',
      description: "Does not typically exacerbate acne conditions"
    }
  }
};

function App() {
  const [selectedMedicine, setSelectedMedicine] = useState<string>('');
  const [skinType, setSkinType] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<MedicineData | null>(null);
  const [showResults, setShowResults] = useState(false);

  const handleAnalyze = () => {
    if (selectedMedicine && skinType) {
      // Simulate API call
      setTimeout(() => {
        setAnalysisResult(mockMedicineData);
        setShowResults(true);
      }, 1500);
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-600 bg-green-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'high': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getConfidenceColor = (score: number) => {
    if (score >= 0.9) return 'text-green-600';
    if (score >= 0.8) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg">
                <Beaker className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold" style={{ color: '#3A0519' }}>
                  MedAnalyzer Pro
                </h1>
                <p className="text-sm text-gray-600">Advanced Medical Information Platform</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 px-4 py-2 bg-yellow-50 rounded-lg border border-yellow-200">
                <AlertTriangle className="h-5 w-5 text-yellow-600" />
                <span className="text-sm font-medium text-yellow-800">Demo Version</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Medical Disclaimer */}
      <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center">
            <Shield className="h-5 w-5 text-red-400 mr-3" />
            <div>
              <p className="text-sm text-red-800 font-medium">
                <strong>Medical Disclaimer:</strong> This is a demonstration platform with mock data. 
                Always consult healthcare professionals for medical advice. Do not use for actual medical decisions.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-4" style={{ color: '#3A0519' }}>
              Medication Analysis & Skin Impact Assessment
            </h2>
            <p className="text-gray-600 text-lg">
              Understand your medication's chemical composition and potential skin-related effects
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Medicine Search */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Search Medicine
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  value={selectedMedicine}
                  onChange={(e) => setSelectedMedicine(e.target.value)}
                  placeholder="Enter medication name (e.g., Acetaminophen)"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Skin Type Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Your Skin Type
              </label>
              <select
                value={skinType}
                onChange={(e) => setSkinType(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                <option value="">Select your skin type</option>
                <option value="sensitive">Sensitive</option>
                <option value="dry">Dry</option>
                <option value="oily">Oily</option>
                <option value="combination">Combination</option>
                <option value="acnerone">Acne-prone</option>
              </select>
            </div>
          </div>

          <div className="mt-6 text-center">
            <button
              onClick={handleAnalyze}
              disabled={!selectedMedicine || !skinType}
              className="px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-medium rounded-lg hover:from-purple-700 hover:to-pink-700 disabled:from-gray-400 disabled:to-gray-400 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105"
            >
              Analyze Medicine
            </button>
          </div>
        </div>

        {/* Results Section */}
        {showResults && analysisResult && (
          <div className="space-y-6">
            {/* Medicine Overview */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-2xl font-bold" style={{ color: '#3A0519' }}>
                  {analysisResult.name}
                </h3>
                <button className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-200">
                  <Download className="h-4 w-4" />
                  <span>Export Report</span>
                </button>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Active Ingredients</h4>
                  <ul className="space-y-1">
                    {analysisResult.activeIngredients.map((ingredient, index) => (
                      <li key={index} className="text-gray-600 flex items-center">
                        <div className="w-2 h-2 bg-purple-500 rounded-full mr-2"></div>
                        {ingredient}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Skin Risk Assessment</h4>
                  <div className="flex items-center space-x-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getRiskColor(analysisResult.skinTypeRisks[skinType]?.risk || 'low')}`}>
                      {analysisResult.skinTypeRisks[skinType]?.risk?.toUpperCase() || 'LOW'} RISK
                    </span>
                    <span className="text-sm text-gray-600">for {skinType} skin</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Chemical Composition */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-bold mb-4" style={{ color: '#3A0519' }}>
                Chemical Composition Analysis
              </h3>
              
              <div className="space-y-4">
                {analysisResult.chemicalComposition.map((compound, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-gray-800">{compound.compound}</h4>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${getRiskColor(compound.skinRisk)}`}>
                          {compound.skinRisk.toUpperCase()}
                        </span>
                        <span className={`text-sm font-medium ${getConfidenceColor(compound.confidenceScore)}`}>
                          {(compound.confidenceScore * 100).toFixed(0)}% confidence
                        </span>
                      </div>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Percentage: </span>
                        <span className="font-medium">{compound.percentage}%</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Function: </span>
                        <span className="font-medium">{compound.function}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Skin-Specific Recommendations */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-bold mb-4" style={{ color: '#3A0519' }}>
                Personalized Skin Assessment
              </h3>
              
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Eye className="h-5 w-5 text-purple-600" />
                  <span className="font-medium">For {skinType} skin type:</span>
                </div>
                <p className="text-gray-700">
                  {analysisResult.skinTypeRisks[skinType]?.description}
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Potential Side Effects</h4>
                  <ul className="space-y-1">
                    {analysisResult.sideEffects.map((effect, index) => (
                      <li key={index} className="text-gray-600 text-sm flex items-start">
                        <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
                        {effect}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Monitoring Recommendations</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li className="flex items-start">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-2 mt-2"></div>
                      Watch for unusual skin reactions
                    </li>
                    <li className="flex items-start">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-2 mt-2"></div>
                      Discontinue if rash develops
                    </li>
                    <li className="flex items-start">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-2 mt-2"></div>
                      Consult dermatologist if concerned
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p className="text-sm">
              © 2025 MedAnalyzer Pro - Demo Version. Not for actual medical use.
            </p>
            <p className="text-xs mt-2">
              Always consult healthcare professionals for medical advice and treatment decisions.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;